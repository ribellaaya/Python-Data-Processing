@echo off
REM Training Report Generator - Windows Launcher
REM This script runs the training report generator with automatic date handling

setlocal enabledelayedexpansion

echo ========================================
echo Training Report Generator - Windows
echo ========================================
echo.

REM Get current directory (project root)
set "PROJECT_ROOT=%~dp0"
set "PYTHON_DIR=%PROJECT_ROOT%python"

REM Check if python directory exists
if not exist "%PYTHON_DIR%" (
    echo ERROR: Python directory not found: %PYTHON_DIR%
    echo Please ensure the project structure is correct.
    pause
    exit /b 1
)

REM Change to python directory
cd /d "%PYTHON_DIR%"

REM Check if virtual environment exists
if exist ".venv\Scripts\activate.bat" (
    echo Found virtual environment. Activating...
    call .venv\Scripts\activate.bat
) else if exist "venv\Scripts\activate.bat" (
    echo Found virtual environment. Activating...
    call venv\Scripts\activate.bat
) else (
    echo No virtual environment found. Using system Python.
    echo To create a virtual environment, run:
    echo   python -m venv .venv
    echo.
)

REM Get current date in format: DD Month YYYY
for /f "tokens=1-3 delims=/ " %%a in ('date /t') do (
    set DATE_RAW=%%a
)

REM Parse date (this works for most Windows locales, but may need adjustment)
REM Alternative: use PowerShell for more reliable date formatting
for /f "delims=" %%a in ('powershell -Command "Get-Date -Format 'dd MMMM yyyy'"') do set CURRENT_DATE=%%a

echo Current date: %CURRENT_DATE%
echo.

REM Check if date argument is provided
if "%~1"=="" (
    echo Using current date for folder selection...
    set "DATE_ARG=%CURRENT_DATE%"
) else (
    echo Using provided date: %*
    set "DATE_ARG=%*"
)

REM Check if main.py exists
if not exist "main.py" (
    echo ERROR: main.py not found in %PYTHON_DIR%
    pause
    exit /b 1
)

REM Run the main script
echo.
echo ========================================
echo Running Training Report Generator...
echo ========================================
echo.

python main.py %DATE_ARG%

REM Capture exit code
set EXIT_CODE=%ERRORLEVEL%

REM Return to project root
cd /d "%PROJECT_ROOT%"

REM Display completion message
echo.
if %EXIT_CODE% equ 0 (
    echo ========================================
    echo Report generation completed successfully!
    echo ========================================
) else (
    echo ========================================
    echo Report generation failed with error code: %EXIT_CODE%
    echo ========================================
)

echo.
echo Press any key to exit...
pause >nul

exit /b %EXIT_CODE%
