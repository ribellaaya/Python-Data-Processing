"""
Training Report Generator
Combines employee mapping data with training progress logs to create a comprehensive report.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime


def get_paths(date_str=None):
    """
    Get paths for source and result directories based on date.
    
    Args:
        date_str: Date string in format 'DD Month YYYY' (e.g., '15 January 2026')
                 If None, uses current date
    
    Returns:
        tuple: (source_dir, result_dir) as Path objects
    """
    # Get the project root (parent of python folder)
    project_root = Path(__file__).parent.parent
    
    # Use provided date or current date
    if date_str is None:
        date_str = datetime.now().strftime('%d %B %Y')
    
    # Construct paths
    source_dir = project_root / 'source data' / f'source data - {date_str}'
    result_dir = project_root / 'result' / f'result data - {date_str}'
    
    # Create result directory if it doesn't exist
    result_dir.mkdir(parents=True, exist_ok=True)
    
    return source_dir, result_dir


def load_data(source_dir):
    """Load all required data sources."""
    print("Loading data sources...")
    
    # Source A: Employee mapping data
    mapping_path = source_dir / 'Mapping User Data.xlsx'
    if not mapping_path.exists():
        raise FileNotFoundError(f"Mapping file not found: {mapping_path}")
    
    df_mapping = pd.read_excel(mapping_path)
    print(f"✓ Loaded {len(df_mapping)} employees from Mapping User Data")
    
    # Source B: Progress logs (find the CSV file)
    csv_files = list(source_dir.glob('LearnerDetail*.csv'))
    if not csv_files:
        raise FileNotFoundError(f"No LearnerDetail CSV file found in: {source_dir}")
    
    csv_path = csv_files[0]  # Use the first matching file
    df_progress = pd.read_csv(csv_path)
    print(f"✓ Loaded {len(df_progress)} progress records from {csv_path.name}")
    
    return df_mapping, df_progress


def parse_curriculum(df_mapping):
    """Parse the List of Content Name column to extract course lists for each employee."""
    print("\nParsing curriculum requirements...")
    
    # Create a dictionary: email -> list of required courses
    curriculum_dict = {}
    
    for _, row in df_mapping.iterrows():
        email = row['Email']
        course_list_str = row['List of Content Name']
        
        # Parse the comma-separated course list
        if pd.notna(course_list_str):
            # Split by comma and clean up whitespace
            courses = [course.strip() for course in str(course_list_str).split(',')]
            curriculum_dict[email] = courses
        else:
            curriculum_dict[email] = []
    
    # Get all unique courses across all employees
    all_courses = set()
    for courses in curriculum_dict.values():
        all_courses.update(courses)
    
    print(f"✓ Parsed curriculum for {len(curriculum_dict)} employees")
    print(f"✓ Found {len(all_courses)} unique courses across all curricula")
    
    return curriculum_dict, sorted(list(all_courses))


def prepare_progress_data(df_progress):
    """Prepare progress data for lookup."""
    print("\nPreparing progress data...")
    
    # Clean the Percent Completed column
    df_progress['Percent_Clean'] = df_progress['Percent Completed'].apply(
        lambda x: float(str(x).replace('%', '')) / 100 if pd.notna(x) and str(x).strip() != '' else 0.0
    )
    
    # Create a lookup: (email, course_name) -> percent_completed
    # Group by Email and Content Name, taking the maximum progress for each course
    progress_lookup = {}
    
    for _, row in df_progress.iterrows():
        email = row['Email']
        course = row['Content Name']
        percent = row['Percent_Clean']
        
        key = (email, course)
        if key in progress_lookup:
            # Keep the highest progress
            progress_lookup[key] = max(progress_lookup[key], percent)
        else:
            progress_lookup[key] = percent
    
    print(f"✓ Prepared progress lookup with {len(progress_lookup)} unique (employee, course) combinations")
    
    return progress_lookup


def build_report(df_mapping, curriculum_dict, all_courses, progress_lookup):
    """Build the final report with dynamic course columns."""
    print("\nBuilding report structure...")
    
    report_data = []
    
    for _, row in df_mapping.iterrows():
        email = row['Email']
        employee_name = row['Name']
        required_courses = curriculum_dict.get(email, [])
        total_courses = row['Total Courses']
        
        # Build row starting with employee data
        report_row = {
            'Employee Name': employee_name,
            'Email': email,
            'Tech Lead': row['Tech Lead'],
            'Domain': row['Domain'],
            'Course Category': row['Course Category']
        }
        
        # Add dynamic course columns (only for courses in this employee's curriculum)
        course_percentages = []
        for course in required_courses:
            key = (email, course)
            percent = progress_lookup.get(key, 0.0)
            report_row[course] = percent
            course_percentages.append(percent)
        
        # Calculate Grand Total
        if total_courses > 0 and len(course_percentages) > 0:
            grand_total = sum(course_percentages) / total_courses
        else:
            grand_total = 0.0
        
        report_row['Grand Total'] = grand_total
        
        # Determine Status
        if grand_total == 0.0:
            status = 'Not Started'
        elif grand_total >= 1.0:
            status = 'Completed'
        else:
            status = 'In‑Progress'
        
        report_row['Status'] = status
        
        report_data.append(report_row)
    
    # Create DataFrame
    df_report = pd.DataFrame(report_data)
    
    # Reorder columns: Employee data, then all unique courses, then metrics
    base_columns = ['Employee Name', 'Email', 'Tech Lead', 'Domain', 'Course Category']
    metric_columns = ['Grand Total', 'Status']
    
    # Get course columns that actually appear in the data
    course_columns = [col for col in df_report.columns if col not in base_columns + metric_columns]
    
    # Final column order
    final_columns = base_columns + course_columns + metric_columns
    df_report = df_report[final_columns]
    
    print(f"✓ Report built with {len(df_report)} employees and {len(course_columns)} course columns")
    
    return df_report


def format_and_export(df_report, output_path):
    """Format the report and export to Excel."""
    print("\nFormatting and exporting report...")
    
    # Create a copy for export with formatted percentages
    df_export = df_report.copy()
    
    # Identify course columns and Grand Total for percentage formatting
    base_columns = ['Employee Name', 'Email', 'Tech Lead', 'Domain', 'Course Category']
    metric_columns = ['Grand Total', 'Status']
    course_columns = [col for col in df_export.columns if col not in base_columns + metric_columns]
    
    # Export to Excel
    with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
        df_export.to_excel(writer, index=False, sheet_name='Training Report')
        
        # Get workbook and worksheet
        workbook = writer.book
        worksheet = writer.sheets['Training Report']
        
        # Format percentage columns
        from openpyxl.styles import numbers
        
        for col_idx, col_name in enumerate(df_export.columns, start=1):
            if col_name in course_columns + ['Grand Total']:
                for row_idx in range(2, len(df_export) + 2):  # Start from row 2 (after header)
                    cell = worksheet.cell(row=row_idx, column=col_idx)
                    cell.number_format = numbers.FORMAT_PERCENTAGE_00
        
        # Auto-adjust column widths
        for column in worksheet.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)  # Cap at 50
            worksheet.column_dimensions[column_letter].width = adjusted_width
    
    print(f"✓ Report exported to: {output_path}")


def main(date_str=None):
    """
    Main execution function.
    
    Args:
        date_str: Optional date string in format 'DD Month YYYY' (e.g., '15 January 2026')
                 If None, uses current date
    """
    print("=" * 80)
    print("TRAINING REPORT GENERATOR")
    print("=" * 80)
    
    # Get paths based on date
    source_dir, result_dir = get_paths(date_str)
    print(f"\nSource directory: {source_dir}")
    print(f"Result directory: {result_dir}")
    
    # Step 1: Load data
    df_mapping, df_progress = load_data(source_dir)
    
    # Step 2: Parse curriculum requirements
    curriculum_dict, all_courses = parse_curriculum(df_mapping)
    
    # Step 3: Prepare progress data
    progress_lookup = prepare_progress_data(df_progress)
    
    # Step 4: Build report
    df_report = build_report(df_mapping, curriculum_dict, all_courses, progress_lookup)
    
    # Step 5: Export report
    output_path = result_dir / 'Training_Report_Output.xlsx'
    format_and_export(df_report, output_path)
    
    print("\n" + "=" * 80)
    print("REPORT GENERATION COMPLETE!")
    print("=" * 80)
    print(f"\nSummary:")
    print(f"  - Total Employees: {len(df_report)}")
    print(f"  - Completed: {len(df_report[df_report['Status'] == 'Completed'])}")
    print(f"  - In Progress: {len(df_report[df_report['Status'] == 'In‑Progress'])}")
    print(f"  - Not Started: {len(df_report[df_report['Status'] == 'Not Started'])}")
    print(f"\nOutput file: {output_path}")


if __name__ == "__main__":
    import sys
    
    # Check if date argument is provided
    if len(sys.argv) > 1:
        date_arg = ' '.join(sys.argv[1:])
        main(date_arg)
    else:
        main()
