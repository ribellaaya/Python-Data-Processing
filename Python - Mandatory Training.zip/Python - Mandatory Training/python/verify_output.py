"""
Verify Output Utility
Compares generated output with example report to verify correctness.
"""

import pandas as pd
from pathlib import Path
from datetime import datetime


def get_paths(date_str=None):
    """Get source and result directory paths."""
    project_root = Path(__file__).parent.parent
    
    if date_str is None:
        date_str = datetime.now().strftime('%d %B %Y')
    
    source_dir = project_root / 'source data' / f'source data - {date_str}'
    result_dir = project_root / 'result' / f'result data - {date_str}'
    
    return source_dir, result_dir


def main(date_str=None):
    """Verify the generated output against example."""
    source_dir, result_dir = get_paths(date_str)
    
    output_path = result_dir / 'Training_Report_Output.xlsx'
    example_path = source_dir / 'Report Example.xlsx'
    
    print(f"Output file: {output_path}")
    print(f"Example file: {example_path}\n")
    
    # Check if files exist
    if not output_path.exists():
        print(f"❌ Output file not found: {output_path}")
        return
    
    if not example_path.exists():
        print(f"⚠️  Example file not found: {example_path}")
        print("Showing output file details only...\n")
        
        # Load output only
        output = pd.read_excel(output_path)
        print("=" * 80)
        print("OUTPUT FILE")
        print("=" * 80)
        print(f"Columns ({len(output.columns)}): {output.columns.tolist()[:10]}...")
        print(f"Total rows: {len(output)}")
        print("\nFirst 2 rows:")
        print(output.head(2))
        return
    
    # Load both files
    output = pd.read_excel(output_path)
    example = pd.read_excel(example_path)
    
    print("=" * 80)
    print("OUTPUT FILE")
    print("=" * 80)
    print(f"Columns ({len(output.columns)}): {output.columns.tolist()[:10]}...")
    print(f"Total rows: {len(output)}")
    print("\nFirst 2 rows:")
    print(output.head(2))
    
    print("\n" + "=" * 80)
    print("EXAMPLE FILE")
    print("=" * 80)
    print(f"Columns ({len(example.columns)}): {example.columns.tolist()}")
    print(f"Total rows: {len(example)}")
    print("\nFirst 2 rows:")
    print(example.head(2))
    
    print("\n" + "=" * 80)
    print("COMPARISON")
    print("=" * 80)
    
    # Find common employees
    common_emails = set(output['Email']).intersection(set(example['Email']))
    print(f"Common employees in both files: {len(common_emails)}")
    
    if len(common_emails) > 0:
        sample_email = list(common_emails)[0]
        print(f"\nSample employee: {sample_email}")
        
        output_row = output[output['Email'] == sample_email].iloc[0]
        example_row = example[example['Email'] == sample_email].iloc[0]
        
        print(f"\nOutput - Employee Name: {output_row['Employee Name']}")
        print(f"Output - Grand Total: {output_row['Grand Total']:.2%}")
        print(f"Output - Status: {output_row['Status']}")
        
        print(f"\nExample - Employee Name: {example_row['Employee Name']}")
        print(f"Example - Grand Total: {example_row['Grand Total']:.2%}")
        print(f"Example - Status: {example_row['Status']}")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        date_arg = ' '.join(sys.argv[1:])
        main(date_arg)
    else:
        main()
