# Quick Reference Card

## 🚀 Run the Report Generator

### Windows
```bash
run.bat
```

### Linux/Mac
```bash
./run.sh
```

### With Custom Date
```bash
run.bat 10 January 2026
```

---

## 📁 Folder Structure

```
Python - Mandatory Training/
├── python/              # Code
├── source data/         # Input files
│   └── source data - 15 January 2026/
├── result/              # Output files
│   └── result data - 15 January 2026/
├── run.bat             # Windows launcher
└── run.sh              # Linux/Mac launcher
```

---

## 📥 Add New Data

1. Create folder: `source data/source data - [Date]/`
2. Add files:
   - `Mapping User Data.xlsx`
   - `LearnerDetail_*.csv`
3. Run: `run.bat [Date]`

---

## 🔧 First-Time Setup

```bash
cd python
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

---

## 📊 Output Location

```
result/result data - 15 January 2026/Training_Report_Output.xlsx
```

---

## 🛠️ Utility Commands

### Examine Files
```bash
cd python
python examine_files.py
```

### Verify Output
```bash
cd python
python verify_output.py
```

---

## 📅 Date Format

Always use: **DD Month YYYY**

Examples:
- `15 January 2026`
- `01 March 2026`
- `31 December 2025`

---

## ⚡ Common Issues

**Module not found?**
```bash
cd python
pip install -r requirements.txt
```

**File not found?**
- Check date format: `DD Month YYYY`
- Verify files in correct folder

**Permission denied? (Linux/Mac)**
```bash
chmod +x run.sh
```

---

## 📚 More Help

See [README.md](README.md) for full documentation
