# Training Report Generator

A Python application that generates comprehensive training reports by combining employee mapping data with training progress logs.

## Project Structure

```
Python - Mandatory Training/
├── python/                          # Python source code
│   ├── main.py                     # Main report generator
│   ├── examine_files.py            # Utility to examine data files
│   ├── verify_output.py            # Utility to verify output
│   └── requirements.txt            # Python dependencies
├── source data/                     # Input data files
│   └── source data - DD Month YYYY/
│       ├── Mapping User Data.xlsx
│       └── LearnerDetail_*.csv
├── result/                          # Generated output files
│   └── result data - DD Month YYYY/
│       └── Training_Report_Output.xlsx
├── run.bat                          # Windows launcher script
└── run.sh                           # Linux/Mac launcher script
```

## First-Time Setup

### 1. Install Python
- Windows: Download from [python.org](https://www.python.org/downloads/)
- Linux: `sudo apt install python3 python3-pip python3-venv`
- Mac: `brew install python3`

### 2. Create Virtual Environment (Recommended)

**Windows:**
```bash
cd "C:\Users\ridha.ayanda\Documents\Python - Mandatory Training\python"
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

**Linux/Mac:**
```bash
cd ~/Documents/Python\ -\ Mandatory\ Training/python
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 3. Prepare Source Data

Create the source data folder with today's date:
```
source data/source data - DD Month YYYY/
```

Place your input files in this folder:
- `Mapping User Data.xlsx` - Employee master data with curriculum assignments
- `LearnerDetail_*.csv` - Training progress logs (any name starting with LearnerDetail)

**Example:**
```
source data/source data - 15 January 2026/
├── Mapping User Data.xlsx
└── LearnerDetail_31Jul2025-14Jan2026.csv
```

## How to Run

### Option 1: Using Launcher Scripts (Easiest)

**Windows:**
```bash
# Double-click run.bat in Windows Explorer
# Or from command prompt:
run.bat
```

**Linux/Mac:**
```bash
# Make script executable (first time only):
chmod +x run.sh

# Run the script:
./run.sh
```

The launcher scripts will:
- Automatically use today's date for folder selection
- Activate virtual environment if it exists
- Run the report generator
- Display success/error messages

### Option 2: Using Custom Date

If your source data folder has a different date, specify it as an argument:

**Windows:**
```bash
run.bat 10 January 2026
```

**Linux/Mac:**
```bash
./run.sh 10 January 2026
```

### Option 3: Direct Python Execution

From the `python/` directory:

**Windows:**
```bash
cd python
.venv\Scripts\activate
python main.py
# Or with custom date:
python main.py 10 January 2026
```

**Linux/Mac:**
```bash
cd python
source .venv/bin/activate
python3 main.py
# Or with custom date:
python3 main.py 10 January 2026
```

## Input Files

### 1. Mapping User Data.xlsx
Employee master data containing:
- **Employee ID** - Unique identifier
- **Name** - Employee name
- **Email** - Employee email address
- **Domain** - Business domain
- **Tech Lead** - Assigned tech lead
- **Course Category** - Training category
- **List of Content Name** - Comma-separated list of required courses
- **Total Courses** - Total number of required courses

### 2. LearnerDetail_*.csv
Training progress logs containing:
- **Name** - Employee name
- **Email** - Employee email address
- **Content Name** - Course name
- **Percent Completed** - Completion percentage (e.g., "75%" or "0.75")

## Output Structure

The generated Excel report (`Training_Report_Output.xlsx`) includes:

### Employee Information (Left columns)
- Employee Name
- Email
- Tech Lead
- Domain
- Course Category

### Dynamic Course Columns (Middle)
- One column per course assigned to each employee
- Shows percentage completed (0-100%)
- Only includes courses from employee's curriculum

### Metrics (Right columns)
- **Grand Total**: Overall completion = Sum of course percentages / Total Courses
- **Status**:
  - "Not Started" if Grand Total = 0%
  - "In-Progress" if Grand Total = 1-99%
  - "Completed" if Grand Total = 100%

## Utility Scripts

### Examine Files
Inspect the structure and content of your input files:

**Windows:**
```bash
cd python
python examine_files.py
```

**Linux/Mac:**
```bash
cd python
python3 examine_files.py
```

### Verify Output
Compare generated output with example report (if available):

**Windows:**
```bash
cd python
python verify_output.py
```

**Linux/Mac:**
```bash
cd python
python3 verify_output.py
```

## Troubleshooting

### "Module not found" Error
Install dependencies:
```bash
cd python
pip install -r requirements.txt
```

### "File not found" Error
- Ensure source data folder exists with correct date format
- Verify input files are in the correct location
- Check file names match expected patterns

### Wrong Date Folder
Use date argument when running:
```bash
run.bat 15 January 2026
# or
./run.sh 15 January 2026
```

### Permission Denied (Linux/Mac)
Make the script executable:
```bash
chmod +x run.sh
```

## Date Format

The application uses the format: **DD Month YYYY**

Examples:
- `15 January 2026`
- `01 March 2026`
- `31 December 2025`

This format is used for:
- Source data folder: `source data/source data - 15 January 2026/`
- Result folder: `result/result data - 15 January 2026/`

## Dependencies

- **pandas** >= 2.0.0 - Data manipulation
- **numpy** >= 1.24.0 - Numerical operations
- **openpyxl** >= 3.1.0 - Excel file handling

## Notes

- Result folders are created automatically if they don't exist
- The script finds any CSV file starting with "LearnerDetail" in the source folder
- Percentage formatting is applied automatically in the Excel output
- Column widths are auto-adjusted for readability
- Virtual environment is optional but recommended for dependency isolation

## Migration from Old Structure

If you have files in the old structure, move them as follows:

**Python files** → `python/`
- `generate_training_report.py` → `python/main.py`
- `examine_files.py` → `python/examine_files.py`
- `verify_output.py` → `python/verify_output.py`

**Data files** → `source data/source data - 15 January 2026/`
- `Mapping User Data.xlsx`
- `LearnerDetail_*.csv`

**Virtual environment** → `python/.venv/` (optional, can recreate)

All file paths in the code have been updated to use relative paths based on the new structure.

## Key Features

1. **Dynamic Columns**: Each employee gets columns only for their assigned courses
2. **Accurate Matching**: Matches employees to courses using Email as the key
3. **Progress Aggregation**: Takes the maximum progress if multiple records exist for the same course
4. **Percentage Formatting**: All percentages formatted properly in Excel
5. **Status Calculation**: Automatically determines training status

## Example Output

```
| Employee Name | Email | Tech Lead | Domain | Course Category | Course 1 | Course 2 | ... | Grand Total | Status |
|--------------|-------|-----------|--------|----------------|----------|----------|-----|-------------|---------|
| John Doe     | j@... | Manager   | Backend| Engineering    | 100%     | 50%      | ... | 75%         | In‑Progress |
```

## Summary Statistics
After running, the script displays:
- Total employees processed
- Number completed (100%)
- Number in progress (1-99%)
- Number not started (0%)

## Troubleshooting

If you encounter issues:
1. Ensure all input files are in the correct location
2. Check that Excel files are not open in another application
3. Verify pandas and openpyxl are installed: `pip install pandas openpyxl`
4. Check that Email addresses match between the two source files
