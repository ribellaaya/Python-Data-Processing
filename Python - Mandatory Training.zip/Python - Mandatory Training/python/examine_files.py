"""
Examine Files Utility
Examines the structure and content of input data files.
"""

import pandas as pd
from pathlib import Path
from datetime import datetime


def get_source_path(date_str=None):
    """Get the source data directory path."""
    project_root = Path(__file__).parent.parent
    
    if date_str is None:
        date_str = datetime.now().strftime('%d %B %Y')
    
    source_dir = project_root / 'source data' / f'source data - {date_str}'
    return source_dir


def main(date_str=None):
    """Examine all data files."""
    source_dir = get_source_path(date_str)
    print(f"Examining files in: {source_dir}\n")
    
    # Examine Mapping User Data
    print("=" * 80)
    print("MAPPING USER DATA")
    print("=" * 80)
    
    mapping_path = source_dir / 'Mapping User Data.xlsx'
    if mapping_path.exists():
        df_mapping = pd.read_excel(mapping_path)
        print('Columns:', df_mapping.columns.tolist())
        print(f'\nTotal rows: {len(df_mapping)}')
        print('\nFirst 3 rows:')
        print(df_mapping.head(3))
    else:
        print(f"File not found: {mapping_path}")
    
    # Examine Report Example (if it exists)
    print("\n" + "=" * 80)
    print("REPORT EXAMPLE")
    print("=" * 80)
    
    report_path = source_dir / 'Report Example.xlsx'
    if report_path.exists():
        df_report = pd.read_excel(report_path)
        print('Columns:', df_report.columns.tolist())
        print(f'\nTotal rows: {len(df_report)}')
        print('\nFirst 2 rows:')
        print(df_report.head(2))
    else:
        print(f"File not found: {report_path}")
    
    # Examine CSV
    print("\n" + "=" * 80)
    print("LEARNER DETAIL CSV")
    print("=" * 80)
    
    csv_files = list(source_dir.glob('LearnerDetail*.csv'))
    if csv_files:
        csv_path = csv_files[0]
        print(f"Found: {csv_path.name}")
        df_csv = pd.read_csv(csv_path)
        print('Columns:', df_csv.columns.tolist())
        print(f'\nTotal rows: {len(df_csv)}')
        print('\nFirst 2 rows:')
        print(df_csv.head(2))
    else:
        print(f"No LearnerDetail CSV files found in: {source_dir}")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        date_arg = ' '.join(sys.argv[1:])
        main(date_arg)
    else:
        main()
