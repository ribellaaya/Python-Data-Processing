#!/bin/bash
# Training Report Generator - Linux/Mac Launcher
# This script runs the training report generator with automatic date handling

echo "========================================"
echo "Training Report Generator - Linux/Mac"
echo "========================================"
echo ""

# Get the directory where this script is located (project root)
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="$SCRIPT_DIR"
PYTHON_DIR="$PROJECT_ROOT/python"

# Check if python directory exists
if [ ! -d "$PYTHON_DIR" ]; then
    echo "ERROR: Python directory not found: $PYTHON_DIR"
    echo "Please ensure the project structure is correct."
    exit 1
fi

# Change to python directory
cd "$PYTHON_DIR" || exit 1

# Check if virtual environment exists and activate it
if [ -f ".venv/bin/activate" ]; then
    echo "Found virtual environment. Activating..."
    source .venv/bin/activate
elif [ -f "venv/bin/activate" ]; then
    echo "Found virtual environment. Activating..."
    source venv/bin/activate
else
    echo "No virtual environment found. Using system Python."
    echo "To create a virtual environment, run:"
    echo "  python3 -m venv .venv"
    echo ""
fi

# Get current date in format: DD Month YYYY
CURRENT_DATE=$(date "+%d %B %Y")
echo "Current date: $CURRENT_DATE"
echo ""

# Check if date argument is provided
if [ $# -eq 0 ]; then
    echo "Using current date for folder selection..."
    DATE_ARG="$CURRENT_DATE"
else
    echo "Using provided date: $*"
    DATE_ARG="$*"
fi

# Check if main.py exists
if [ ! -f "main.py" ]; then
    echo "ERROR: main.py not found in $PYTHON_DIR"
    exit 1
fi

# Run the main script
echo ""
echo "========================================"
echo "Running Training Report Generator..."
echo "========================================"
echo ""

python3 main.py "$DATE_ARG"

# Capture exit code
EXIT_CODE=$?

# Return to project root
cd "$PROJECT_ROOT" || exit 1

# Display completion message
echo ""
if [ $EXIT_CODE -eq 0 ]; then
    echo "========================================"
    echo "Report generation completed successfully!"
    echo "========================================"
else
    echo "========================================"
    echo "Report generation failed with error code: $EXIT_CODE"
    echo "========================================"
fi

exit $EXIT_CODE
