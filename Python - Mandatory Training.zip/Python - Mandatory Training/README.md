# Python - Mandatory Training

Automated training report generator for employee course completion tracking.

## Quick Start

### Windows
```bash
# Double-click run.bat or run from command prompt:
run.bat

# With custom date:
run.bat 10 January 2026
```

### Linux/Mac
```bash
chmod +x run.sh
./run.sh

# With custom date:
./run.sh 10 January 2026
```

## Project Structure

```
Python - Mandatory Training/
├── python/              # All Python code and documentation
│   ├── docs/           # Full documentation
│   ├── main.py         # Main report generator
│   └── requirements.txt
├── source data/         # Input data (organized by date)
│   └── source data - DD Month YYYY/
├── result/              # Generated reports (organized by date)
│   └── result data - DD Month YYYY/
├── run.bat             # Windows launcher
└── run.sh              # Linux/Mac launcher
```

## Documentation

Comprehensive documentation is available in the `python/docs/` folder:

- **[Setup Guide](python/docs/README.md)** - Complete setup and usage instructions
- **[Quick Reference](python/docs/QUICK_REFERENCE.md)** - Quick command reference card
- **[Change Log](python/docs/RESTRUCTURING_COMPLETE.md)** - Detailed restructuring notes

## First-Time Setup

```bash
cd python
python -m venv .venv
.venv\Scripts\activate     # Windows
# source .venv/bin/activate  # Linux/Mac
pip install -r requirements.txt
```

## Adding New Data

1. Create folder: `source data/source data - [DD Month YYYY]/`
2. Add your files:
   - `Mapping User Data.xlsx`
   - `LearnerDetail_*.csv`
3. Run: `run.bat [DD Month YYYY]`

## Output

Generated reports are saved to:
```
result/result data - [DD Month YYYY]/Training_Report_Output.xlsx
```

## Requirements

- Python 3.8+
- pandas >= 2.0.0
- numpy >= 1.24.0
- openpyxl >= 3.1.0

---

For detailed documentation, see [python/docs/README.md](python/docs/README.md)
